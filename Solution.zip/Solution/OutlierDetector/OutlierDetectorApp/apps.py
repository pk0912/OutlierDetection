from django.apps import AppConfig


class OutlierdetectorappConfig(AppConfig):
    name = 'OutlierDetectorApp'
